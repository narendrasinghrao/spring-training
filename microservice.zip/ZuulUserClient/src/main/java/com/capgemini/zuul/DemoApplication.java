package com.capgemini.zuul;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.cloud.client.circuitbreaker.EnableCircuitBreaker;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.http.client.BufferingClientHttpRequestFactory;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;

@SpringBootApplication
@EnableCircuitBreaker
public class DemoApplication {
	public static void main(String[] args) {
		ApplicationContext ctx = SpringApplication.run(DemoApplication.class,
				args);
		
		UserController userController=ctx.getBean(UserController.class);
		userController.disMessage();
		//userController.getEmployee();
	}

	@Bean
	public  UserController userController()
	{
		return  new UserController();
	}
	
	@Bean
	public RestTemplate restTemplate() {
		RestTemplate template =new RestTemplate();
		return template;
	}

	@Bean
	public User getUser() {
		return new User();
	}
	
	@Bean
	public UserService getUserService() {
		return new UserService();
	}
}
