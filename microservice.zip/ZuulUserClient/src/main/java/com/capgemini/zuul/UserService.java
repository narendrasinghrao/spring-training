package com.capgemini.zuul;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.ui.Model;
import org.springframework.web.client.RestTemplate;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

public class UserService {

	@Autowired
	RestTemplate restTemplate;
	@Autowired
	User user;
	@Autowired
	private DiscoveryClient discoveryClient;
	@HystrixCommand(fallbackMethod="fallbackAdd")
	public int add(User user){

		List<ServiceInstance> instances=discoveryClient.getInstances("user-zuul-service");
		ServiceInstance serviceInstance=instances.get(0);

		String baseUrl=serviceInstance.getUri().toString();
 		String uri=baseUrl+"/producer1/addUser";
 		//	String uri = "http://localhost:8037/addUser";
		int id= restTemplate.postForObject(uri, user,Integer.class);
		return id;
	}
	
	public int delete(int id){

		List<ServiceInstance> instances=discoveryClient.getInstances("user-zuul-service");
		ServiceInstance serviceInstance=instances.get(0);

		String baseUrl=serviceInstance.getUri().toString();
 		String uri=baseUrl+"/producer/deleteUser/"+id;
		restTemplate.delete(uri);
		return id;
	}

	public List<User> show(){
		List<ServiceInstance> instances=discoveryClient.getInstances("user-zuul-service");
		ServiceInstance serviceInstance=instances.get(0);
		String baseUrl=serviceInstance.getUri().toString();
		String uri=baseUrl+"/producer/showUser";
		List<User> user= restTemplate.getForObject(uri,List.class);
		return user;
	}
	public int fallbackAdd(User user){
		return -1;
	}
}
