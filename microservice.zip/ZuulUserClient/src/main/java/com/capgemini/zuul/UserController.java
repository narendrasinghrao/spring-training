package com.capgemini.zuul;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.cloud.client.loadbalancer.LoadBalancerClient;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;


@RefreshScope
@Controller
public class UserController {
	@Autowired
	UserService service;
	/*@Autowired
	private LoadBalancerClient loadBalancer;*/
	
	 @Value("${message:Hello default}")
	    private String message;

	@RequestMapping(value="/")
	public String home(Model model){
		model.addAttribute("configMsg",message);
		return "index";
	}
	
	public void disMessage(){
		System.out.println(message);
	}
	
	@RequestMapping(value="/addindex")
	public String addindex(){
		return "adduser";
	}

	@RequestMapping(value = "/addUser")
	public String add(@ModelAttribute User user,Model model){
		int id=service.add(user);
		if(id==-1)
		{
			model.addAttribute("msg","Unable to add detail due to internal error");
			return "adduser";
		}
		else{
			model.addAttribute("id",id);
			return "addsuccess";
		}
	}

	@RequestMapping(value = "/deleteUser")
	public String delete(@RequestParam("id") int id,Model model){
		model.addAttribute("msg","User details deleted With id "+service.delete(id));
		List<User> user=service.show();
		model.addAttribute("user", user);
		return "showdetails";
	}

	@RequestMapping(value = "/showUser")
	public String show(Model model){
		List<User> user=service.show();
		model.addAttribute("user", user);
		return "showdetails";
	}
}
