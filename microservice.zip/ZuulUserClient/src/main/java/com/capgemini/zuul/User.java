package com.capgemini.zuul;

public class User {
	private int id;
	private String name;
	private String emailid;
	private int age;
	
	public User() {
		// TODO Auto-generated constructor stub
	}

	public User(int id, String name, String emailid, int age) {
		super();
		this.id =id;
		this.name = name;
		this.emailid = emailid;
		this.age = age;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmailid() {
		return emailid;
	}

	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	@Override
	public String toString() {
		return "User [userid=" + id + ", name=" + name + ", emailid="
				+ emailid + ", age=" + age + "]";
	}
	
	

}
