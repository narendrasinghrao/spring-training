package com.cg.user;


import java.util.List;

import javax.websocket.server.PathParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class UserController {
	@Autowired
	UserRepository repo;

	@RequestMapping("/addUser")
	public int add(@RequestBody User user,Model model){
		User user1=repo.save(user);
		return user1.getId();
	}
	
	@RequestMapping("/deleteUser/{id}")
	public int delete(@PathVariable("id") Integer id,Model model){
		System.out.println("ID :"+id);
		User user = new User();
		user.setId(id);
		repo.delete(user);
		return id;
	}
	
	
	@RequestMapping("/showUser")
	public List<User> show(@PathParam("name") String name,Model model){
		List<User> user=(List<User>) repo.findAll();
		for (User user2 : user) {
			System.out.println(user2);
		}
		
		return user;
	}
}
